﻿using AdminApi.Data.AppDbContext;
using AdminApi.Data.Models;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AdminApi.Data.Services;
using AdminApi.Models;
using Microsoft.AspNetCore.Authorization;
using System.IO;
// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace AdminApi.Controllers
{
	[Route("api/[controller]")]
	[Authorize(Policy ="ApiReader")]
	[ApiController]
	public class AdminController : ControllerBase
	{
		public IAdminService _admindao;
		public AdminController(IAdminService admin) {
			_admindao = admin;
		}
		#region Doctor
		[HttpGet("/Doctors")]
		[Authorize(Policy ="RoleAdmin")]
		public IEnumerable<DoctorMaster> GetDoctor()
		{
			var header = HttpContext.Request;
			try {
				return _admindao.GetAllDoctor();
			} catch (Exception e) {
				return null;
			}
		}   

		[Authorize(Policy = "RoleAdmin")]
		[HttpGet("/Doctor/{id}")]
		public DoctorMaster Get(int id)
		{
			try
			{
				return _admindao.GetDoctor(id);
			}
			catch (Exception e) {
				return null;
			}
		}
        
        [HttpPost("/Doctor")]
        public void Post([FromBody] string doctor)
        {
            ResultModel res = new ResultModel();
            try
            {
                res.Code = 1;
                res.Response = "Successfully Registered";
            }
            catch (Exception e)
            {
                res.Code = 4;
                res.Response = e.Message;
            }
        }
        #endregion
        #region Nurse
        
		[Authorize(Policy = "RoleAdmin")]
		[HttpGet("/Nurses")]
		public IEnumerable<NurseMaster> GetNurse()
		{
			try
			{
				return _admindao.GetAllNurse();
			}
			catch (Exception e)
			{
				return null;
			}
		}

        [Authorize(Policy = "RoleAdmin")]
        [HttpGet("/Nurse/{id}")]
        public NurseMaster Getnurse(int id)
        {
            try
            {
                return _admindao.GetNurse(id);
            }
            catch (Exception e)
            {
                return null;
            }
        }
        [HttpPost("/Nurse")]
        public void PostNurse([FromBody] string nurse)
        {
            ResultModel res = new ResultModel();
            try
            {
                res.Code = 1;
                res.Response = "Successfully Registered";
            }
            catch (Exception e)
            {
                res.Code = 4;
                res.Response = e.Message;
            }
        }
        #endregion
        #region Patient
        [HttpGet("/Patients")]
        public IEnumerable<PatientMaster> GetAllPatient()
        {
            try
            {
                return _admindao.GetAllPatient();
            }
            catch (Exception e)
            {
                return null;
            }
        }
        [Authorize(Policy = "Role")]
        [HttpGet("/Patient/{id}")]
        public PatientMaster GetPatient(int id)
        {
            try
            {
                return _admindao.GetPatient(id);
            }
            catch (Exception e)
            {
                return null;
            }
        }
        #endregion

        [HttpGet("/getClaims")]
        [AllowAnonymous]
        public ActionResult<IEnumerable<string>> Get()
        {
            return new JsonResult(User.Claims.Select(c => new { c.Type, c.Value }));
        }
        [HttpGet]
        [Route("/userInfo")]
        public object GetUserDetails()
        {
            ResultModel res = new ResultModel();
            try
            {
                var userid = GetUserId();
                if (String.IsNullOrEmpty(userid))
                {
                    return null;
                }
                else
                {
                    return (_admindao.GetUserDetail(userid));
                }
            }
            catch (Exception e)
            {

            }
            return null;
        }
        //[HttpGet("/UserId")]
        //[AllowAnonymous]
        [NonAction]
        public string GetUserId()
        {
            return User.Claims.Where(x => x.Type.Contains("nameidentifier")).Select(c => c.Value).FirstOrDefault();
        }

        /// <summary>
        /// To download excel file
        /// </summary>
        [HttpGet("/getexcelreport")]
        [AllowAnonymous]
        public IActionResult DownloadExcelReport(string entityName)
        {
            try
            {
                ListtoDataTableConverter convert = new ListtoDataTableConverter(_admindao);
                MemoryStream mem = new MemoryStream();
                mem = convert.CreateExcel(entityName);
                return File(mem.ToArray(), "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "Report.xlsx");
            }
            catch (Exception e)
            {
                return BadRequest();
            }
        }


        [HttpGet("/getadmindashboarddata")]
        [AllowAnonymous]
        public object GetAdminDashBoardData()
        {
            try
            {
                return (_admindao.GetAdminDashBoardData());
            }
            catch (Exception e)
            {
                return null;
            }
            return null;
        }

        [HttpGet("/getdoctordashboarddata")]
        [AllowAnonymous]
        public object GetDoctorDashBoardData(string userName)
        {
            try
            {
                return (_admindao.GetDoctorDashBoardData(userName));
            }
            catch (Exception e)
            {
                return null;
            }
            return null;
        }

        [HttpGet("/getpatientdashboarddata")]
        [AllowAnonymous]
        public object GetPatientDashBoardData(string userName)
        {
            try
            {
                return (_admindao.GetPatientDashBoardData(userName));
            }
            catch (Exception e)
            {
                return null;
            }
            return null;
        }

        [HttpGet("/getnursedashboarddata")]
        [AllowAnonymous]
        public object GetNurseDashBoardData(string userName)
        {
            try
            {
                return (_admindao.GetNurseDashBoardData());
            }
            catch (Exception e)
            {
                return null;
            }
            return null;
        }

    }
}
