﻿using AdminApi.Data.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AdminApi.Data.AppDbContext;
namespace AdminApi.Data.Services
{
	public class AdminService : IAdminService
	{
		private PMSYSTEMContext _ctx;
		public AdminService(PMSYSTEMContext context) {
			_ctx = context;
		}
		public IEnumerable<DoctorMaster> GetAllDoctor()
		{
			var res = _ctx.DoctorMasters.Join(_ctx.AspNetUsers, d => d.UserLoginDetailsId, a => a.Id, (d, a) => new { d, a }).Select(s => new DoctorMaster
			{
				UserLoginDetailsId = s.d.UserLoginDetailsId,
				DoctorDisplayId = s.d.DoctorDisplayId,
				FirstName = s.d.FirstName,
				LastName = s.d.LastName,
				IsActive = s.d.IsActive,
				PhoneNo = s.d.PhoneNo,
				Speciality = s.d.Speciality,
				Title = s.d.Title,
				Id = s.d.Id,
				EmailId = s.d.EmailId,
				Dob = s.d.Dob,
				Age = s.d.Age,
				Address = s.d.Address,
				IsLocked = (s.a.LockoutEnabled && (s.a.LockoutEnd != null ? s.a.LockoutEnd <= DateTime.Now : false)),
			});
			return res;
		}

		public IEnumerable<NurseMaster> GetAllNurse()
		{
			var res = _ctx.NurseMasters.Join(_ctx.AspNetUsers, d => d.UserLoginDetailsId, a => a.Id, (d, a) => new { d, a }).Select(s => new NurseMaster
			{
				UserLoginDetailsId = s.d.UserLoginDetailsId,
				NurseDisplayId = s.d.NurseDisplayId,
				FirstName = s.d.FirstName,
				LastName = s.d.LastName,
				IsActive = s.d.IsActive,
				PhoneNo = s.d.PhoneNo,
				Title = s.d.Title,
				Id = s.d.Id,
				EmailId = s.d.EmailId,
				Dob = s.d.Dob,
				Age = s.d.Age,
				Address = s.d.Address,
				IsLocked = (s.a.LockoutEnabled && (s.a.LockoutEnd != null ? s.a.LockoutEnd <= DateTime.Now : false)),
			});
			return res;
		}

		public IEnumerable<PatientMaster> GetAllPatient()
		{
			var res = _ctx.PatientMasters.Join(_ctx.AspNetUsers, d => d.UserLoginDetailsId, a => a.Id, (d, a) => new { d, a }).Select(s => new PatientMaster
			{
				UserLoginDetailsId = s.d.UserLoginDetailsId,
				PatientDisplayId = s.d.PatientDisplayId,
				FirstName = s.d.FirstName,
				LastName = s.d.LastName,
				IsActive = s.d.IsActive,
				PhoneNo = s.d.PhoneNo,
				Title = s.d.Title,
				Id = s.d.Id,
				EmailId = s.d.EmailId,
				Dob = s.d.Dob,
				Age = s.d.Age,
				Address = s.d.Address,
				IsLocked = (s.a.LockoutEnabled && (s.a.LockoutEnd != null ? s.a.LockoutEnd <= DateTime.Now : false)),
			});
			return res;
		}

		public DoctorMaster GetDoctor(int Id)
		{
			return _ctx.DoctorMasters.Where(x=>x.Id == Id).FirstOrDefault();
		}

		public NurseMaster GetNurse(int Id)
		{
			return _ctx.NurseMasters.Where(x=>x.Id == Id).FirstOrDefault();
		}

		public PatientMaster GetPatient(int Id)
		{
			return _ctx.PatientMasters.Where(x=>x.Id==Id).FirstOrDefault();
		}
		public object GetUserDetail(string Uid) {
			var role = _ctx.AspNetUserClaims.Where(x => x.UserId == Uid && x.ClaimType == "role").Select(y => y.ClaimValue).FirstOrDefault();
			switch(role) {
				case "admin": {
						var resA = _ctx.AspNetUsers.Where(x => x.Id == Uid).Select(s=>new { 
							Id = s.Id,
							Name = s.Name,
							UserName = s.UserName,
							Email = s.Email,
							PhoneNumber = s.PhoneNumber,
							Role = "Admin"
						}).FirstOrDefault();
						return resA;
					}
				case "doctor": {
						var resA = _ctx.AspNetUsers.Where(x => x.Id == Uid).Join(_ctx.DoctorMasters, a=>a.Id, d=>d.UserLoginDetailsId,(a,d)=>new { a,d }).Select(s=> new {
							Id = s.a.Id,
							Name = s.a.Name,
							UserName = s.a.UserName,
							Email = s.a.Email,
							PhoneNumber = s.d.PhoneNo,
							FirstName = s.d.FirstName,
							LastName = s.d.LastName,
							Address = s.d.Address,
							City = s.d.City,
							Role="Doctor"
						}).FirstOrDefault();
						return resA;
					}
				case "nurse": {
						var resA = _ctx.AspNetUsers.Where(x => x.Id == Uid).Join(_ctx.NurseMasters, a => a.Id, d => d.UserLoginDetailsId, (a, d) => new { a, d }).Select(s => new {
							Id = s.a.Id,
							Name = s.a.Name,
							UserName = s.a.UserName,
							Email = s.a.Email,
							PhoneNumber = s.d.PhoneNo,
							FirstName = s.d.FirstName,
							LastName = s.d.LastName,
							Address = s.d.Address,
							City = s.d.City,
							Role = "Nurse"
						}).FirstOrDefault();
						return resA;
					}
				case "patient": {
						var resA = _ctx.AspNetUsers.Where(x => x.Id == Uid).Join(_ctx.PatientMasters, a => a.Id, d => d.UserLoginDetailsId, (a, d) => new { a, d }).Select(s => new {
							Id = s.a.Id,
							Name = s.a.Name,
							UserName = s.a.UserName,
							Email = s.a.Email,
							PhoneNumber = s.d.ContactNumber,
							FirstName = s.d.FirstName,
							LastName = s.d.LastName,
							Address = s.d.Address,
							City = s.d.City,
							Role = "Patient"
						}).FirstOrDefault();
						return resA;
					}
                default: {
						return null;
					}
			}
		}
    
        //public object GetUserDetail(string Uid)
        //{
        //    throw new NotImplementedException();
        //}

        public Object GetAdminDashBoardData()
        {
            int totalDoctors = 0;
            int totalActiveDoctors = 0;
            int totalInActiveDoctors = 0;
            int totalLockedDoctors = 0;

            int totalPatients = 0;
            int totalActivePatients = 0;
            int totalInActivePatients = 0;
            int totalLockedPatients = 0;

            int totalNurses = 0;
            int totalActiveNurses = 0;
            int totalInActiveNurses = 0;
            int totalLockedNurses = 0;

            totalDoctors = _ctx.DoctorMasters.ToList().Count;
            totalActiveDoctors = _ctx.DoctorMasters.Where(x => x.IsActive == true).ToList().Count;
            totalInActiveDoctors = _ctx.DoctorMasters.Where(x => x.IsActive == false).ToList().Count;
            totalLockedDoctors = (from a in  _ctx.AspNetUsers
                                  join b in _ctx.DoctorMasters
                                  on new { cond1 = a.Id } equals new { cond1 = b.UserLoginDetailsId }
                                  where a.AccessFailedCount >= 3
                                  select new
                                  {
                                      Id=b.Id
                                  }).ToList().Count;



            totalPatients = _ctx.PatientMasters.ToList().Count;
            totalActivePatients = _ctx.PatientMasters.Where(x => x.IsActive == true).ToList().Count;
            totalInActivePatients = _ctx.PatientMasters.Where(x => x.IsActive == false).ToList().Count;
            totalLockedPatients = (from a in _ctx.AspNetUsers
                                   join b in _ctx.PatientMasters
                                   on new { cond1 = a.Id } equals new { cond1 = b.UserLoginDetailsId }
                                   where a.AccessFailedCount >= 3
                                   select new
                                   {
                                       Id = b.Id
                                   }).ToList().Count;

            totalNurses = _ctx.NurseMasters.ToList().Count;
            totalActiveNurses = _ctx.NurseMasters.Where(x => x.IsActive == true).ToList().Count;
            totalInActiveNurses = _ctx.NurseMasters.Where(x => x.IsActive == false).ToList().Count;
            totalLockedNurses = (from a in _ctx.AspNetUsers
                                 join b in _ctx.NurseMasters
                                 on new { cond1 = a.Id } equals new { cond1 = b.UserLoginDetailsId }
                                 where a.AccessFailedCount >= 3
                                 select new
                                 {
                                     Id = b.Id
                                 }).ToList().Count;


            var data = new
            {
                totalDoctors = totalDoctors,
                totalActiveDoctors = totalActiveDoctors,
                totalInActiveDoctors = totalInActiveDoctors,
                totalLockedDoctors= totalLockedDoctors,
                totalPatients = totalPatients,
                totalActivePatients = totalActivePatients,
                totalInActivePatients = totalInActivePatients,
                totalLockedPatients= totalLockedPatients,
                totalNurses = totalNurses,
                totalActiveNurses = totalActiveNurses,
                totalInActiveNurses = totalInActiveNurses,
                totalLockedNurses= totalLockedNurses
            };

            return data;
        }

        public Object GetDoctorDashBoardData(string userName)
        {
            int totalAppointments = 0;
            int totalApproved = 0;
            int totalRejected = 0;
            int totalPending = 0;


            AspNetUser user = _ctx.AspNetUsers.SingleOrDefault(x => x.UserName == userName);
            int doctorId = _ctx.DoctorMasters.Where(x => x.UserLoginDetailsId == user.Id).SingleOrDefault().Id;

            totalAppointments = _ctx.Appointments.Where(x => x.DoctorId == doctorId).ToList().Count();
            totalApproved = _ctx.Appointments.Where(x => x.DoctorId == doctorId && x.IsConfirmed == true).ToList().Count();
            totalRejected = _ctx.Appointments.Where(x => x.DoctorId == doctorId && x.IsConfirmed == false).ToList().Count();
            totalPending = _ctx.Appointments.Where(x => x.DoctorId == doctorId && x.IsConfirmed == null).ToList().Count();

            var data = new
            {
                totalAppointments = totalAppointments,
                totalApproved = totalApproved,
                totalRejected = totalRejected,
                totalPending = totalPending
            };

            return data;
        }

        public Object GetPatientDashBoardData(string userName)
        {
            //int height = 0;
            //int weight = 0;
            //int systolicBP = 0;
            //int diastolicBP = 0;
            //int bodyTemp = 0;
            //int respirationRate = 0;

            AspNetUser user = _ctx.AspNetUsers.SingleOrDefault(x => x.UserName == userName);
            int patientId = _ctx.PatientMasters.Where(x => x.UserLoginDetailsId == user.Id).SingleOrDefault().Id;

            PatientVitalSign patientVitalSign = new PatientVitalSign();
            patientVitalSign = _ctx.PatientVitalSigns.Where(x => x.PatientId == patientId).OrderByDescending(x => x.Id).FirstOrDefault();


            if (patientVitalSign != null)
            {
                var data = new
                {
                    height = patientVitalSign.Height,
                    weight = patientVitalSign.Weight,
                    systolicBP = patientVitalSign.BloodPressureSystolic,
                    diastolicBP = patientVitalSign.BloodPressureDiastolic,
                    bodyTemp = patientVitalSign.BodyTemperature,
                    respirationRate = patientVitalSign.BodyTemperature
                };
                return data;
            }
            else
            {
                return null;
            }


        }

        public Object GetNurseDashBoardData()
        {
            int totalAppointments = 0;
            int totalApproved = 0;
            int totalRejected = 0;
            int totalPending = 0;
            int totalPatients = 0;
            int totalActivePatients = 0;

            totalAppointments = _ctx.Appointments.ToList().Count();
            totalApproved = _ctx.Appointments.Where(x => x.IsConfirmed == true).ToList().Count();
            totalRejected = _ctx.Appointments.Where(x => x.IsConfirmed == false).ToList().Count();
            totalPending = _ctx.Appointments.Where(x => x.IsConfirmed == null).ToList().Count();

            totalPatients = _ctx.PatientMasters.ToList().Count;
            totalActivePatients = _ctx.PatientMasters.Where(x => x.IsActive == true).ToList().Count;

            var data = new
            {
                totalAppointments = totalAppointments,
                totalApproved = totalApproved,
                totalRejected = totalRejected,
                totalPending = totalPending,
                totalPatients= totalPatients,
                totalActivePatients= totalActivePatients
            };

            return data;
        }
    }
}
